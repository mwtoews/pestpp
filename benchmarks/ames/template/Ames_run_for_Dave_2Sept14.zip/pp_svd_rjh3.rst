start_iteration 1  1
base_par_iteration
termination_info_1 30 0 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3 
jacobian_model_runs_built -1
jacobian_saved
upgrade_model_runs_built -1
start_iteration 1  2
super_par_iteration
upgrade_model_runs_built -1
start_iteration 2  3
super_par_iteration
upgrade_model_runs_built -1
start_iteration 3  4
super_par_iteration
upgrade_model_runs_built -1
start_iteration 4  5
super_par_iteration
upgrade_model_runs_built -1
start_iteration 5  6
super_par_iteration
upgrade_model_runs_built -1
start_iteration 1  7
base_par_iteration
termination_info_1 30 6 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3  2.23326 2.24734 3.20522 3.20601
jacobian_model_runs_built -1
jacobian_saved
upgrade_model_runs_built -1
start_iteration 1  8
super_par_iteration
upgrade_model_runs_built -1
start_iteration 2  9
super_par_iteration
upgrade_model_runs_built -1
