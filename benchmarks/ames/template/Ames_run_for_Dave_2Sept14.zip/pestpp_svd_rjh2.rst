start_iteration 1  1
base_par_iteration
jacobian_model_runs_built 2
termination_info_1 30 0 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3 
jacobian_saved
upgrade_model_runs_built 3
start_iteration 2  2
base_par_iteration
jacobian_model_runs_built 4
termination_info_1 30 1 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3  3.2469
jacobian_saved
upgrade_model_runs_built 5
start_iteration 1  3
super_par_iteration
upgrade_model_runs_built 7
start_iteration 2  4
super_par_iteration
upgrade_model_runs_built 9
start_iteration 1  5
base_par_iteration
jacobian_model_runs_built 10
termination_info_1 30 4 4 0 4
termination_info_2 1 4 0.005 0.005
termination_info_3  2.24267 2.36114 2.5108 3.2469
jacobian_saved
upgrade_model_runs_built 11
start_iteration 2  6
base_par_iteration
jacobian_model_runs_built 12
termination_info_1 30 5 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3  2.18327 2.24267 2.36114 2.5108
jacobian_saved
upgrade_model_runs_built 13
start_iteration 1  7
super_par_iteration
upgrade_model_runs_built 15
start_iteration 2  8
super_par_iteration
upgrade_model_runs_built 17
start_iteration 1  9
base_par_iteration
jacobian_model_runs_built 18
termination_info_1 30 8 4 1 4
termination_info_2 0 4 0.005 0.005
termination_info_3  2.14405 2.14484 2.14909 2.18327
jacobian_saved
upgrade_model_runs_built 19
start_iteration 2  10
base_par_iteration
jacobian_model_runs_built 20
termination_info_1 30 9 4 0 4
termination_info_2 0 4 0.005 0.005
termination_info_3  2.12324 2.14405 2.14484 2.14909
jacobian_saved
upgrade_model_runs_built 21
start_iteration 1  11
super_par_iteration
upgrade_model_runs_built 23
start_iteration 2  12
super_par_iteration
upgrade_model_runs_built 25
start_iteration 1  13
base_par_iteration
jacobian_model_runs_built 26
termination_info_1 30 12 4 0 4
termination_info_2 2 4 0.005 0.005
termination_info_3  2.09925 2.10563 2.12324 2.12705
jacobian_saved
upgrade_model_runs_built 27
start_iteration 2  14
base_par_iteration
jacobian_model_runs_built 28
termination_info_1 30 13 4 0 4
termination_info_2 3 4 0.005 0.005
termination_info_3  2.06236 2.09925 2.10563 2.12324
jacobian_saved
upgrade_model_runs_built 29
start_iteration 1  15
super_par_iteration
upgrade_model_runs_built 31
start_iteration 2  16
super_par_iteration
upgrade_model_runs_built 33
